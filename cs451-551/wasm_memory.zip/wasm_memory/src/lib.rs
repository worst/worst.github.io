#![no_std]

use core::panic::PanicInfo;
use core::slice::from_raw_parts_mut;


// Set some WebAssembly memory to a given value
// That JS will be able to read from
#[no_mangle]
pub fn memory_from_wasm_to_js() {
    let wasm_memory: &mut [u8];

    unsafe {
        wasm_memory = from_raw_parts_mut::<u8>(0 as *mut u8, 1)    
    }
    
    wasm_memory[0] = 255;

}

#[panic_handler]
fn panic(_info: &PanicInfo) -> !{
    loop{}
}