// #![no_std]

use core::panic::PanicInfo;
use core::slice::from_raw_parts_mut;


// Set some WebAssembly memory to a given value
// That JS will be able to read from
#[no_mangle]
pub fn memory_from_wasm_to_js() {
    let wasm_memory: &mut [u8];

    unsafe {
        wasm_memory = from_raw_parts_mut::<u8>(0 as *mut u8, 1)    
    }
    
    wasm_memory[0] = 255;

}

// #[panic_handler]
// fn panic(_info: &PanicInfo) -> !{
//     loop{}
// }

// bring in the allocator api functions
use std::alloc::{alloc, dealloc, Layout};
use std::slice;
use std::mem;

// write our own malloc for the javascript side of things
// to be able to allocate wasm module memory
#[no_mangle]
fn malloc1(size: usize) -> *mut u8 {
    // we want to align on a u8
    let alignment = std::mem::align_of::<usize>();

    // let's go ahead and create our memory alignment
    // ::from_size_align returns an Option type
    if let Ok(layout) = Layout::from_size_align(size, alignment) {
        // ok we were able to create a layout with the given size
        // and alignment

        // we need to call std::alloc::alloc
        // which is *unsafe*
        unsafe {
            if layout.size() > 0 {
                let pointer: *mut u8 = alloc(layout);

                // check to make sure it's not a null pointer!
                if !pointer.is_null() {
                    return pointer;
                }
            }
            // else {
            //     // what are the consequences of doing this error here
            //     // versus just aborting?
            //     // return alignment as *mut u8;

            //     std
            // }
        }
    }

    // we get here if we fail anywhere else above!
    std::process::abort();
}

#[no_mangle]
pub fn sum(data: *mut u8, len: usize) -> i32 {

    // create a slice from the memory that was allocated
    // by a js call to malloc()
    let array_set_by_js = unsafe {
        std::slice::from_raw_parts(data as *const u8, len)
    };

    let mut sum = 0;

    // now add up all the items in the array
    for i in 0..len {
        sum = sum + array_set_by_js[i];
    }

    sum as i32


}








