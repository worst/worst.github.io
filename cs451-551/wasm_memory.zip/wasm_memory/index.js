function main() {
	// alert("hi");
	memoryFromWasmToJs();
	memoryFromJsToWasm();
}

async function memoryFromWasmToJs() {
	// download the wasm
	const bytes = await fetch("target/wasm32-unknown-unknown/debug/wasm_memory.wasm");
	// get the downloaded wasm as a byte array
	const wasmBytes = await bytes.arrayBuffer();
	// instantiate a webassembly module
	const wasm = await WebAssembly.instantiate(wasmBytes, {});

	// we can call exported functions from wasm
	wasm.instance.exports.memory_from_wasm_to_js();

	const wasmMemory = new Uint8Array(
		wasm.instance.exports.memory.buffer,
		0);

	alert("wasmMemory[0] = " + wasmMemory[0]);
}

async function memoryFromJsToWasm() {
	// we're going to directly modify the webassembly memory
	// from javascript

	const bytes = await fetch("target/wasm32-unknown-unknown/debug/wasm_memory.wasm");
	
	// get the downloaded wasm as a byte array
	const wasmBytes = await bytes.arrayBuffer();

	// insantiate wasm memory object
	const wasmJsMemory = new WebAssembly.Memory(
		{
			initial: 10,
			maximum: 100
		}
	);

	// instatiate the web assembly module
	// and pass it an option for creating the
	// initial wasm memory
	const wasm = await WebAssembly.instantiate(
		wasmBytes,
		{ js: { mem: wasmJsMemory } }
	);

	wasm.instance.exports.memory_from_wasm_to_js();

	// one step to load the webassembly module
	// const wasm = await WebAssembly.instantiateStreaming(
	// 	fetch("target/wasm32-unknown-unknown/debug/wasm_memory.wasm"),
	//  { js: { mem: wasmJsMemory } }
	// );

	// we are going to have rust add up some numbers
	// rust is good at math!

	// create a javascript Set
	// this lives in the JS engine memory, it's garbage
	// collected, etc.
	const to_add = new Set([1, 2, 3, 4, 5]);

	// we are going to directly put these into memory
	// and we don't want to have to encode them into bytes
	// this array lives in javascript memory
	let jsArray = Uint8Array.from(to_add);

	const len = jsArray.length;

	// let's allocate some memory in wasm module
	let wasmPointer = wasm.instance.exports.malloc(len);

	// create a js array that is really the wasm
	// module memory
	let wasmArray = new Uint8Array(
		wasm.instance.exports.memory.buffer,
		wasmPointer,
		len
	);

	// manipulating wasmArray is the equivalent of
	// directly manipulating wasm memory

	wasmArray.set(jsArray);

	let sum = wasm.instance.exports.sum(wasmPointer, len);

	alert("wasm.sum(" + jsArray + ") = " + sum);


}

main();