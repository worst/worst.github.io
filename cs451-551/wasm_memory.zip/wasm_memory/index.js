function main() {
	alert("hi");
	memoryFromWasmToJs();
}

async function memoryFromWasmToJs() {
	// download the wasm
	const bytes = await fetch("target/wasm32-unknown-unknown/debug/wasm_memory.wasm");
	// get the downloaded wasm as a byte array
	const wasmBytes = await bytes.arrayBuffer();
	// instantiate a webassembly module
	const wasm = await WebAssembly.instantiate(wasmBytes, {});

	// we can call exported functions from wasm
	wasm.instance.exports.memory_from_wasm_to_js();

	const wasmMemory = new Uint8Array(
		wasm.instance.exports.memory.buffer,
		0);

	alert("wasmMemory[0] = " + wasmMemory[0]);
}

main();