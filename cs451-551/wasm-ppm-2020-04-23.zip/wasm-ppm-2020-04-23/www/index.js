import * as wasm from "wasm-ppm";

wasm.greet();

// make a javascript function that sets the content of
// an img element by stuffing it with binary
const setImage = (imageBlob) => {
	// we need to get an arrayBuffer
	// that we can then convert to a Uint8Array
	// which we can then pass straight through to rust
	imageBlob.arrayBuffer().then(
		buff => {
			console.log(buff);

			let byteArray = new Uint8Array(buff);

			console.log(byteArray);

			let bytesFromRust = wasm.image_passthrough(byteArray);

			// now let's go back and stuff the ppm
			// into the javascript
			let ppmBytes = bytesFromRust.buffer;
			let blob = new Blob(
				[ppmBytes],
				{type: 'image/ppm'});

			// stuff these bytes into the
			// img tag on our page
			const url = window.URL.createObjectURL(blob);

			const img = document.getElementById('img-ppm');
			img.src = url;


		}
	);
}

// grab the file from the browser when the user uploads it
// we want the file as an array of bytes
document.getElementById('file-input').addEventListener(
	'change',
	function() {
		var reader = new FileReader();
		var file = this.files[0];

		// async stuff
		// run this function when the reader has fired
		// the online event
		reader.onload = function() {
			var data = new Blob(
				[reader.result],
				{type: 'image/ppm'}
			);

			this.value = '';

			console.log(data);

			setImage(data);
		};

		// actually read the file in
		reader.readAsArrayBuffer(file);
	},
	false
);
