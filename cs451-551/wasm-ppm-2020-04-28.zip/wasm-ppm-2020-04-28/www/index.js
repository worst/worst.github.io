import * as wasm from "wasm-ppm";

import { memory } from "wasm-ppm/wasm_ppm_bg";

// wasm.greet();

// make a javascript function that sets the content of
// an img element by stuffing it with binary
const setImage = (imageBlob) => {
	// we need to get an arrayBuffer
	// that we can then convert to a Uint8Array
	// which we can then pass straight through to rust
	imageBlob.arrayBuffer().then(
		buff => {
			console.log(buff);

			let byteArray = new Uint8Array(buff);

			console.log(byteArray);

			let bytesFromRust = wasm.image_passthrough(byteArray);

			// now let's go back and stuff the ppm
			// into the javascript
			let ppmBytes = bytesFromRust.buffer;
			let blob = new Blob(
				[ppmBytes],
				{type: 'image/ppm'});

			// stuff these bytes into the
			// img tag on our page
			const url = window.URL.createObjectURL(blob);

			const img = document.getElementById('img-ppm');
			img.src = url;


		}
	);
}


const setImageFromMemory = (imageBlob) => {
	// we need to get an arrayBuffer
	// that we can then convert to a Uint8Array
	// which we can then pass straight through to rust
	imageBlob.arrayBuffer().then(
		buff => {
			console.log(buff);

			let byteArray = new Uint8Array(buff);

			// we will need the number of bytes in our image for
			// bookkeeping purposes.
			// There are probably better ways to do this, but we will
			// keep things overly explicit
			let imageLength = byteArray.length;

			console.log(imageLength);

			console.log(byteArray);


			// now we are going to manipulate the image in wasm memory
			// and get a pointer back
			// then we will have the browser download whatever is in that pointer
			let imagePointer = wasm.manipulate_image_in_memory(byteArray);

			let bytesFromRust = new Uint8Array(memory.buffer, imagePointer, imageLength);

			// let bytesFromRust = wasm.image_passthrough(byteArray);


			console.log(bytesFromRust);


			// now let's go back and stuff the ppm
			// into a javascript blob
			let blob = new Blob(
				[bytesFromRust],
				{type: 'image/x-portable-pixmap'});

			// stuff the blob into the
			// img tag on our page
			const imageUrl = window.URL.createObjectURL(blob);

			const img = document.getElementById('img-ppm');
			img.src = imageUrl;


			// now we will use some tricks to get the browser to
			// actually download the file since browser's don't support
			// PPM :(
			
			// see https://gist.github.com/dreamyguy/6b4ab77d2f118adb8a63c4a03fba349d
			const tempLink = document.createElement('a');
  			tempLink.style.display = 'none';
  			tempLink.href = imageUrl;
  			tempLink.setAttribute('download', "test-image.ppm");


			if (typeof tempLink.download === 'undefined') {
    			tempLink.setAttribute('target', '_blank');
  			}
  			document.body.appendChild(tempLink);
  			tempLink.click();
  			document.body.removeChild(tempLink);
  			setTimeout(() => {
    			// For Firefox it is necessary to delay revoking the ObjectURL
    			window.URL.revokeObjectURL(imageUrl);
  			}, 100);


		}
	);
}


// grab the file from the browser when the user uploads it
// we want the file as an array of bytes
document.getElementById('file-input').addEventListener(
	'change',
	function() {
		var reader = new FileReader();
		var file = this.files[0];

		// async stuff
		// run this function when the reader has fired
		// the online event
		reader.onload = function() {
			var data = new Blob(
				[reader.result],
				{type: 'image/ppm'}
			);

			this.value = '';

			console.log(data);

			setImageFromMemory(data);
		};

		// actually read the file in
		reader.readAsArrayBuffer(file);
	},
	false
);
