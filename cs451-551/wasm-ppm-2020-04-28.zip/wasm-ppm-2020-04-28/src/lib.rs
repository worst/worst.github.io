mod utils;

use wasm_bindgen::prelude::*;

// When the `wee_alloc` feature is enabled, use `wee_alloc` as the global
// allocator.
#[cfg(feature = "wee_alloc")]
#[global_allocator]
static ALLOC: wee_alloc::WeeAlloc = wee_alloc::WeeAlloc::INIT;

#[wasm_bindgen]
extern {
    fn alert(s: &str);
}

#[wasm_bindgen]
pub fn greet() {
    alert("Hello, wasm-ppm!");
}

#[wasm_bindgen]
pub fn image_passthrough(data: &[u8]) -> Vec<u8> {

    alert(&format!("image data: {:?}", data));
    let mut ret = Vec::new();
    ret.extend_from_slice(data);

    ret
}

#[wasm_bindgen]
pub fn manipulate_image_in_memory(data: &[u8]) -> *const u8 {
    let mut v: Vec<u8> = Vec::new();

    v.extend_from_slice(data);

    // for x in data {
    //     v.push(*x);
    // }

    // note that this only works for a very specific image!
    // dahlia-red-blossom-bloom-60597.ppm in the
    // data directory!
    for (i, color_val) in data[15..].iter().enumerate() {
        match i % 3 {
            0 => v[i + 15] = 255,
            1 => v[i + 15] = 69,
            2 => v[i + 15] = 0,
            _ => panic!("oh no!"),
        }
    }

    // for i in 15..v.len() {
    //     v[i] = 0;
    // }

    v.as_ptr()
}

