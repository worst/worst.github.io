mod utils;

use wasm_bindgen::prelude::*;

// When the `wee_alloc` feature is enabled, use `wee_alloc` as the global
// allocator.
#[cfg(feature = "wee_alloc")]
#[global_allocator]
static ALLOC: wee_alloc::WeeAlloc = wee_alloc::WeeAlloc::INIT;

#[wasm_bindgen]
extern {
    fn alert(s: &str);
}

#[wasm_bindgen]
pub fn greet() {
    alert("Hello, wasm-ppm!");
}

#[wasm_bindgen]
pub fn image_passthrough(data: &[u8]) -> Vec<u8> {

    alert(&format!("image data: {:?}", data));
    let mut ret = Vec::new();
    ret.extend_from_slice(data);

    ret
}

#[wasm_bindgen]
pub fn manipulate_image_in_memory(data: &[u8]) -> *const u8 {
    // to start with we just want to pass through
    // so whatever we get passed in, we just want
    // to stick it in the wasm memory

    let mut ret = Vec::new();
    ret.extend_from_slice(data);

    // we have a 15 byte header
    // for our hardcoded expected
    // file uploaded dahlia-red-blossom-bloom-60597.ppm

    // let's try turning the entire image white.

    let start = 15; // this skips our hard coded header
    // for i in 15..ret.len() {
    //     // ppm pixels are groups of 3 values
    //     // r g b
    //     // (255, 255, 255) = white
    //     // (0, 0, 0) = black
    //     ret[i] = 255;
    // }

    // now we're going to turn the entire image orange:
    // (255, 69, 0)

    for (i, color_val) in data[start..].iter().enumerate() {
        match i % 3 {
            0 => ret[i + start] = 255,
            1 => ret[i + start] = 69,
            2 => ret[i + start] = 0,
            _ => panic!("this is mathematically impossible"),
        }
    }

    ret.as_ptr()

}

#[wasm_bindgen]
pub fn get_text(input: &str) -> String {
    String::from(input)
}

