/* tslint:disable */
/* eslint-disable */
/**
*/
export function greet(): void;
/**
* @param {Uint8Array} data 
* @returns {Uint8Array} 
*/
export function image_passthrough(data: Uint8Array): Uint8Array;
/**
* @param {Uint8Array} data 
* @returns {number} 
*/
export function manipulate_image_in_memory(data: Uint8Array): number;
/**
* @param {string} input 
* @returns {string} 
*/
export function get_text(input: string): string;
