/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function greet(): void;
export function image_passthrough(a: number, b: number, c: number): void;
export function manipulate_image_in_memory(a: number, b: number): number;
export function get_text(a: number, b: number, c: number): void;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_free(a: number, b: number): void;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
